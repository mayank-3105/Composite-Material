import math

# Maximum number of laminas in the laminate
NUM_LAMINAS = 10

# Structure to store lamina properties
class Lamina:
    def __init__(self, strength, stiffness):
        self.strength = strength  # Ultimate strength
        self.stiffness = stiffness  # Stiffness

# Function to calculate Tsai-Hill FoS
def tsai_hill_fos(Nx, Ny, Nxy, Mx, My, Mxy, sigma1, sigma2, tau12):
    FoS = 1 / math.sqrt((Nx / sigma1) ** 2 + (Ny / sigma2) ** 2 + (Nxy / tau12) ** 2 -
                        Nx * Ny / (sigma1 * sigma2) + 3 * (Mx ** 2 / sigma1 ** 2 + My ** 2 / sigma2 ** 2) +
                        2 * (Mxy ** 2 / tau12 ** 2))
    return FoS

# Function to calculate Tsai-Hill FoS considering partial degradation
def tsai_hill_partial_fos(Nx, Ny, Nxy, Mx, My, Mxy, sigma1, sigma2, tau12, Sf1, Sf2, St12):
    FoS = 1 / math.sqrt((Nx / (sigma1 / Sf1)) ** 2 + (Ny / (sigma2 / Sf2)) ** 2 +
                        (Nxy / (tau12 / St12)) ** 2 -
                        Nx * Ny / ((sigma1 / Sf1) * (sigma2 / Sf2)) +
                        3 * ((Mx / (sigma1 / Sf1)) ** 2 + (My / (sigma2 / Sf2)) ** 2) +
                        2 * ((Mxy / (tau12 / St12)) ** 2))
    return FoS

def main():
    num_laminas = int(input("Enter the number of laminas: "))
    laminas = []

    # Input laminate specifications
    print("Enter stacking sequence of the laminate:")
    for i in range(num_laminas):
        print(f"Lamina {i + 1}: Strength and Stiffness: ", end="")
        strength, stiffness = map(float, input().split())
        laminas.append(Lamina(strength, stiffness))

    # Input applied load
    Nx, Ny, Nxy, Mx, My, Mxy, delta_T, delta_C = map(float, input("Enter applied load (Nx, Ny, Nxy, Mx, My, Mxy, ΔT, ΔC): ").split())

    # Calculate stresses and strains for each lamina and find maximum stress
    sigma_max = -1
    for lamina in laminas:
        # Calculate stresses for each lamina
        sigma1 = (Nx + Mx * lamina.stiffness) / lamina.stiffness
        sigma2 = (Ny + My * lamina.stiffness) / lamina.stiffness
        tau12 = Nxy / lamina.stiffness

        # Calculate maximum stress
        max_stress = math.sqrt(sigma1 ** 2 - sigma1 * sigma2 + sigma2 ** 2 + 3 * tau12 ** 2)
        if max_stress > sigma_max:
            sigma_max = max_stress

    # Calculate FoS using Tsai-Hill theory
    FoS_max = tsai_hill_fos(Nx, Ny, Nxy, Mx, My, Mxy, sigma_max, sigma_max, tau12)
    FoS_partial = tsai_hill_partial_fos(Nx, Ny, Nxy, Mx, My, Mxy, sigma_max, sigma_max, tau12, 1.0, 1.0, 1.0)

    print(f"Factor of Safety using Tsai-Hill Theory (Complete Degradation): {FoS_max}")
    print(f"Factor of Safety using Tsai-Hill Theory (Partial Degradation): {FoS_partial}")

if __name__ == "__main__":
    main()


